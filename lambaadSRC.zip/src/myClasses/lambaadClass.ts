export class Midterm {
    LASTlambaad! : string;
    FIRSTlambaad! : string;
    EMAILlambaad! : string;
    PROGRAMNAMElambaad! : string;
    LOGINlambaad! : string;
}